# NutriProof 2.0 — MVP

A static, trilingual educational web app (French, English, Portuguese) for exploring supplement evidence.

## Included
- 30+ ingredient cards with claims, timing, limitations, precautions and source links (preliminary content; not all entries have formal evidence grading).
- Search across names and aliases, including normalized variants such as MK-7 / MK 7 / MK7.
- Explore by goal and category.
- Local favorites stored in the current browser and JSON export of favorites.
- Print/save detail as PDF using the browser print dialog.

## Limitations
Static prototype only: no backend, account sync, barcode database, product scanner, personalized medical advice or independent systematic review of every card. Favorites remain on the same browser/device.

## Publish on GitHub Pages
Replace the repository root `index.html` with this file and commit to `main`. Keep existing Pages settings.
